
def adder(a, b):
    return a + b

def substractor(a, b):
    return a - b
