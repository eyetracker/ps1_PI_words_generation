import PI.PiGenerator

class Test_PiGenerator():

    def test_basicPowerMod():
        # 5^7 mod 23 = 17
        assert PI.PiGenerator.powerMod(5, 7, 23) == 17
        # 2^2 mod 2 = 0
        assert PI.PiGenerator.powerMod(2, 2, 2) == 0
        # If a < 0, b < 0, or m < 0, return -1.
        assert PI.PiGenerator.powerMod(-5, 7, 23) == -1
        assert PI.PiGenerator.powerMod(5, -7, 23) == -1
        assert PI.PiGenerator.powerMod(5, 7, -23) == -1
        # int max ranges
        assert PI.PiGenerator.powerMod(2, 30, 2) == 0
        assert PI.PiGenerator.powerMod(2, 62, 2) == 0
        assert PI.PiGenerator.powerMod(2, 92, 2) == 0

        #TODO: Write more tests (Problem 1.a, 1.c)

    def test_computePiInHex():
        pass
